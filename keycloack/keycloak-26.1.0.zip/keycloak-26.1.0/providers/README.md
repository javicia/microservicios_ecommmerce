Installing Custom Providers
===========================

Add your custom provider JAR files in this directory.

Once you have your providers in this directory, run the following command to complete the installation:

```
${kc.home.dir}/bin/kc.sh build
```
